pip install -r requirements.txt
python -m pytest tests/test_complexity.py  # Para correr los tests
python demo.py  # Para ver la demostración